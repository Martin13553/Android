package com.example.myapplication1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle ;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
        private EditText loginInput;
        private EditText passwordInput;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            loginInput = findViewById(R.id.password_input3);
            passwordInput = findViewById(R.id.password_input);
        }
        public void onClic(View view) {
            String login = loginInput.getText().toString();
            String password = passwordInput.getText().toString();
            Authorization(login, password);
        }
        private void Authorization(String login, String password){
            if(TextUtils.isEmpty(login)){
                loginInput.setError("Login can not be empty");
            }
            else if(!Patterns.EMAIL_ADDRESS.matcher(login).matches())
                loginInput.setError("Incorrect E-Mail address");
            else if(TextUtils.isEmpty(password)){
                passwordInput.setError("Password can not be empty");
            }
            else if(password.length() < 6){
                passwordInput.setError("Password must be at least 6 characters");
            }
            else if(!password.matches("^(?=.*[!@#$%^&*?]).*$")){
                passwordInput.setError("Password must contain special characters (!@#$%^&*?)");
            }
            else if(!password.matches("(.*[A-Z].*)")){
                passwordInput.setError("Password must contain [A-Z]");
            }
            else{
                Intent profile = new Intent(MainActivity.this,secondW.class);
                profile.putExtra("user_email", login);
                profile.putExtra("user_password", password);
                startActivity(profile);
            }
        }
    }








